import { ConnectKitButton } from 'connectkit'
import { Building2 } from 'lucide-react'

interface HeaderProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

const tabs = [
  { id: 'discover', label: 'Discover' },
  { id: 'list', label: 'List Property' },
  { id: 'transactions', label: 'My Deals' },
  { id: 'profile', label: 'My Profile' },
]

export default function Header({ activeTab, onTabChange }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 border-b backdrop-blur-xl" style={{ background: 'rgba(255,255,255,0.82)', borderColor: 'var(--border)' }}>
      <div className="mx-auto max-w-6xl px-4">
        <div className="flex h-14 items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="flex size-8 items-center justify-center rounded-xl" style={{ background: 'var(--accent)' }}>
              <Building2 className="size-4 text-white" />
            </div>
            <span className="display text-base font-bold tracking-tight hidden sm:block" style={{ color: 'var(--ink)' }}>
              PropChain
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-0.5 rounded-xl p-0.5" style={{ background: 'var(--surface-muted)' }}>
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="rounded-lg px-3 py-1.5 text-sm font-medium transition-all"
                style={{
                  background: activeTab === tab.id ? 'white' : 'transparent',
                  color: activeTab === tab.id ? 'var(--ink)' : 'var(--muted)',
                  boxShadow: activeTab === tab.id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                }}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          <ConnectKitButton />
        </div>

        {/* Mobile nav */}
        <div className="flex md:hidden items-center gap-1 pb-2 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium transition-all"
              style={{
                background: activeTab === tab.id ? 'var(--accent)' : 'var(--surface-muted)',
                color: activeTab === tab.id ? 'white' : 'var(--muted)',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}
