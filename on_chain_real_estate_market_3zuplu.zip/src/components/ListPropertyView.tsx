import { useState } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { Loader2, CheckCircle2, Building, Home, Warehouse, Store } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import {
  REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl, parseUsdc
} from '@/hooks/useRealEstateContract'

const PROPERTY_TYPES = [
  { id: 'apartment', label: 'Apartment', icon: <Building className="size-4" /> },
  { id: 'house', label: 'House', icon: <Home className="size-4" /> },
  { id: 'commercial', label: 'Commercial', icon: <Warehouse className="size-4" /> },
  { id: 'retail', label: 'Retail', icon: <Store className="size-4" /> },
]

export default function ListPropertyView() {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContract, data: hash, isPending, reset } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })

  const [form, setForm] = useState({
    title: '',
    location: '',
    propertyType: 'apartment',
    priceUsdc: '',
    rentPerMonthUsdc: '',
    forSale: true,
    forRent: false,
    metadataUri: '',
  })

  const wrongChain = chainId !== CHAIN_ID

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    if (!address) return
    if (!form.title.trim() || !form.location.trim()) return
    if (form.forSale && !form.priceUsdc) return
    if (form.forRent && !form.rentPerMonthUsdc) return

    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: 'createListing',
      args: [
        form.title.trim(),
        form.location.trim(),
        form.propertyType,
        form.forSale && form.priceUsdc ? parseUsdc(form.priceUsdc) : 0n,
        form.forRent && form.rentPerMonthUsdc ? parseUsdc(form.rentPerMonthUsdc) : 0n,
        form.forSale,
        form.forRent,
        form.metadataUri.trim(),
      ],
      chainId: CHAIN_ID,
    })
  }

  if (isSuccess) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 flex flex-col items-center text-center gap-6">
        <div className="flex size-16 items-center justify-center rounded-full" style={{ background: 'rgba(26,128,71,0.10)' }}>
          <CheckCircle2 className="size-8" style={{ color: 'var(--success)' }} />
        </div>
        <div>
          <h2 className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>Property Listed</h2>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Your listing is now live on-chain and visible in Discover.</p>
        </div>
        {hash && (
          <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-sm underline" style={{ color: 'var(--accent-hover)' }}>
            View transaction
          </a>
        )}
        <button
          onClick={() => { reset(); setForm({ title: '', location: '', propertyType: 'apartment', priceUsdc: '', rentPerMonthUsdc: '', forSale: true, forRent: false, metadataUri: '' }) }}
          className="rounded-2xl px-8 py-3 text-sm font-semibold text-white"
          style={{ background: 'var(--accent)' }}
        >
          List Another Property
        </button>
      </div>
    )
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="display text-2xl font-bold tracking-tight" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>List a Property</h1>
        <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>KYC required to create a listing. Stored on-chain, immutable.</p>
      </div>

      {!address ? (
        <div className="rounded-2xl p-8 flex flex-col items-center gap-4 text-center" style={{ background: 'var(--surface-muted)' }}>
          <Building className="size-8" style={{ color: 'var(--muted)' }} />
          <p style={{ color: 'var(--ink)' }} className="font-medium">Connect your wallet to list a property</p>
          <ConnectKitButton />
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Listing mode */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: 'var(--muted)' }}>Listing Mode</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setForm(f => ({ ...f, forSale: !f.forSale }))}
                className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all border"
                style={{
                  background: form.forSale ? 'var(--accent)' : 'var(--surface-strong)',
                  color: form.forSale ? 'white' : 'var(--muted)',
                  borderColor: form.forSale ? 'var(--accent)' : 'var(--border)',
                }}
              >
                For Sale
              </button>
              <button
                type="button"
                onClick={() => setForm(f => ({ ...f, forRent: !f.forRent }))}
                className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all border"
                style={{
                  background: form.forRent ? 'var(--success)' : 'var(--surface-strong)',
                  color: form.forRent ? 'white' : 'var(--muted)',
                  borderColor: form.forRent ? 'var(--success)' : 'var(--border)',
                }}
              >
                For Rent
              </button>
            </div>
          </div>

          {/* Property type */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: 'var(--muted)' }}>Property Type</label>
            <div className="grid grid-cols-4 gap-2">
              {PROPERTY_TYPES.map(pt => (
                <button
                  key={pt.id}
                  type="button"
                  onClick={() => setForm(f => ({ ...f, propertyType: pt.id }))}
                  className="flex flex-col items-center gap-1.5 rounded-xl py-2.5 text-xs font-medium transition-all border"
                  style={{
                    background: form.propertyType === pt.id ? 'rgba(18,45,69,0.06)' : 'var(--surface-strong)',
                    color: form.propertyType === pt.id ? 'var(--ink)' : 'var(--muted)',
                    borderColor: form.propertyType === pt.id ? 'var(--accent)' : 'var(--border)',
                  }}
                >
                  {pt.icon}
                  {pt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <Field label="Property Title" required>
            <input
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Modern 2BR Apartment"
              className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
              style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
              maxLength={120}
              required
            />
          </Field>

          {/* Location */}
          <Field label="City, Country" required>
            <input
              value={form.location}
              onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              placeholder="Dubai, UAE"
              className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
              style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
              required
            />
          </Field>

          {/* Prices */}
          {form.forSale && (
            <Field label="Sale Price (USDC)" required>
              <div className="relative">
                <input
                  inputMode="decimal"
                  value={form.priceUsdc}
                  onChange={e => setForm(f => ({ ...f, priceUsdc: e.target.value.replace(/[^0-9.]/g, '') }))}
                  placeholder="250000.00"
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border pr-16"
                  style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
                  required={form.forSale}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium" style={{ color: 'var(--muted)' }}>USDC</span>
              </div>
            </Field>
          )}
          {form.forRent && (
            <Field label="Monthly Rent (USDC)" required>
              <div className="relative">
                <input
                  inputMode="decimal"
                  value={form.rentPerMonthUsdc}
                  onChange={e => setForm(f => ({ ...f, rentPerMonthUsdc: e.target.value.replace(/[^0-9.]/g, '') }))}
                  placeholder="1500.00"
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border pr-16"
                  style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
                  required={form.forRent}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium" style={{ color: 'var(--muted)' }}>/mo</span>
              </div>
            </Field>
          )}

          {/* Metadata URI */}
          <Field label="Property Media URI (optional)">
            <input
              value={form.metadataUri}
              onChange={e => setForm(f => ({ ...f, metadataUri: e.target.value }))}
              placeholder="ipfs://... or https://..."
              className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
              style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
            />
          </Field>

          {/* Platform note */}
          {(form.forSale || form.forRent) && (
            <div className="rounded-xl p-3 text-xs" style={{ background: 'rgba(18,45,69,0.04)', color: 'var(--muted)' }}>
              {form.forSale && <p>• 1.5% platform fee on completed purchases</p>}
              {form.forRent && <p>• 0.5% platform fee per monthly rent payment</p>}
              <p className="mt-0.5">• Your KYC status is verified on-chain</p>
            </div>
          )}

          <button
            type="submit"
            disabled={!address || isPending || isConfirming || (!form.forSale && !form.forRent)}
            className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ background: 'var(--accent)' }}
          >
            {!address ? 'Connect Wallet'
              : wrongChain ? 'Switch to Arc Testnet'
              : isPending ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Confirm in wallet...</span>
              : isConfirming ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Listing on-chain...</span>
              : 'Create Listing'}
          </button>
        </form>
      )}
    </div>
  )
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-widest mb-1.5 block" style={{ color: 'var(--muted)' }}>
        {label}{required && <span style={{ color: 'var(--danger)' }}> *</span>}
      </label>
      {children}
    </div>
  )
}
