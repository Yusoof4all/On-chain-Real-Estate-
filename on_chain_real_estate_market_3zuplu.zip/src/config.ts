/**
 * wagmi configuration
 * Built with Arc Studio — https://studio.arc.io
 */

import { http } from 'wagmi'
import { mainnet } from 'wagmi/chains'
import { arcTestnet } from 'viem/chains'
import { getDefaultConfig } from 'connectkit'
import { createConfig } from 'wagmi'
import { registerChain } from './tracing'

// Pre-register chain RPC URLs so trace events show correct chain names immediately
registerChain(arcTestnet.id, arcTestnet.rpcUrls.default.http[0])

export const config = createConfig(
  getDefaultConfig({
    // Chains
    chains: [arcTestnet, mainnet], // mainnet needed for ENS resolution
    transports: {
      [arcTestnet.id]: http(),
      [mainnet.id]: http(),
    },

    // WalletConnect — required for QR-code wallets (MetaMask Mobile, Rainbow, Trust, etc.)
    // Get a free Project ID at https://cloud.walletconnect.com
    walletConnectProjectId: (import.meta.env.VITE_WALLETCONNECT_PROJECT_ID as string) ?? '',

    // App metadata shown in wallet connection modals
    appName: 'PropChain',
    appDescription: 'On-chain real estate — buy, sell, rent, and manage properties with USDC escrow.',
    appUrl: typeof window !== 'undefined' ? window.location.origin : 'https://propchain.app',
    appIcon: typeof window !== 'undefined' ? `${window.location.origin}/favicon.ico` : undefined,
  }),
)
